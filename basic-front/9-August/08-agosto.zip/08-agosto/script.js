// const p1 = new Promise((res, rej) => {
//   if (5 === '5') {
//     res("hello world");
//   } else {
//     rej("rejected");
//   }
// });

// const p2 = new Promise((res, rej) => {
//   if (5 === '5') {
//     res("p1 success");
//   } else {
//     rej("rejected");
//   }
// });

// const p3 = new Promise((res, rej) => {
//   if (5 === '5') {
//     res("p2 success");
//   } else {
//     rej("rejected");
//   }
// });

// Promise.all([p1, p2, p3])
// .then((res) => {
//     console.log(res)
// })
// .catch(rej => console.error(rej))

//Возвращает любой первый результат будь то успех или ошибка
// Promise.race([p1, p2, p3])
// .then(res => console.log(res))
// .catch(rej => console.error(rej))

// Возвращает первый успешный результат из массива промиссов
// Promise.any([p1, p2, p3])
// .then(res => console.log(res))
// .catch(rej => console.error(rej))

// p1.then((response) => {
//   console.log(response);
// }).catch((err) => {
//   console.error(err);
// });

// const obj = {};

// const objMethods = {
//   a: () => {},
//   b: (a, b) => {
//     return a + b;
//   },
// };

// async function fetchApi(url, id) {

//     // try {
//         const response = await fetch(url)
//         // if(!response.ok) {
//         //     throw new Error('There is a mistake!!!')
//         // }
//         const data = await response.json()
//         console.log(data)
//     // } catch(e) {
//     //     console.error('Error: ' + e)
//     // }
// }

// fetchApi('https://jsonplaceholder.typicode.com/todos')

// const fn = async () => {
//     const res = await fetch('https://jsonplaceholder.typicode.com/todos')
//     const data = await res.json()
//     console.log(data)
// }

// fn()
const list = document.querySelector(".list");

function fetchPromiseApi(url, delay) {
    loading()
  setTimeout(() => {
    fetch(url)
      .then((res) => {
        if (!res.ok) {
          throw new Error("Error!!!");
        }
        return res.json();
      })
      .then((data) => {

        data.forEach((item, index) => {
          const desc = `this is description for ${index + 1} element`;
          createPost(item.title, desc);
        });
      })
      .catch((rej) => console.error("Error was made", rej));
  }, delay);
}

fetchPromiseApi("https://jsonplaceholder.typicode.com/todos", 2000);

function createPost(title, body) {
  const listItem = document.createElement("div");
  const titleElement = document.createElement("h3");
  const bodyElement = document.createElement("p");
  titleElement.innerText = title;
  bodyElement.innerText = body;
  listItem.append(titleElement, bodyElement);
  listItem.classList.add("listItem");
  list.appendChild(listItem);
}

function loading() {
    const loader = document.createElement("div");
  loader.classList.add("loader");
  list.appendChild(loader);
}
