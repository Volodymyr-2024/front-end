const container = document.querySelector(".container");
const containerItem = document.querySelector(".container__item");
const refreshBtn = document.querySelector(".refresh__btn");
const urls = {
  catApi:
    "https://api.thecatapi.com/v1/images/search?size=med&mime_types=jpg&format=json&has_breeds=true&order=RANDOM&page=0&limit=1%22,%20requestOptions",
  kanyeWestApi: "https://api.kanye.rest",
};

const fetchCatApi = async () => {
  try {
    const response = await fetch(urls.catApi);
    if (!response.ok) {
      throw new Error("Error is in the response");
    }
    const data = await response.json();
    const kanyeWestQuote = await fetchKanyeWestApi()
    console.log(kanyeWestQuote)
    const catDescription = document.createElement('div')
    const quoteString = document.createElement('p')
    const image = document.createElement("img");
    const catId = document.createElement("div");
    quoteString.innerText = `Kanye west said: ${kanyeWestQuote.quote}`
    catId.innerText = `Cat id: ${data[0].id}`;
    catDescription.append(image, catId, quoteString)
    image.setAttribute("src", data[0].url);
    containerItem.insertAdjacentElement(
      "afterbegin", catDescription
    );
    console.log(data);
  } catch (e) {
    console.error(e);
  }
};

const fetchKanyeWestApi = async () => {
  try {
    const response = await fetch(urls.kanyeWestApi);
    if (!response.ok) {
      throw new Error("Error is in the response");
    }
    const data = await response.json();
    return data
  } catch (e) {
    console.error(e);
  }
};
fetchKanyeWestApi();
fetchCatApi();

refreshBtn.addEventListener("click", () => {
  location.reload();
});
