// class Person {

//     constructor(name) {
//         this.name = name
//     }

//     sayHello() {
//         console.log(`Hello, my name is ${this.name}`)
//     }
// }

// const person1 = new Person('kelly')
// person1.sayHello()

// class Cat {
//     constructor(petName) {
//         this.petName = petName
//     }

//     sayMeow() {
//         console.log(`The cat ${this.petName} says MEEEEEOW`)
//     }
// }

// const eliseiCat = new Cat('Elisei')
// eliseiCat.sayMeow()

// class Animal extends Cat {
//     constructor(asc) {
//         super(asc)
//     }
//     sleep() {
//         console.log(`The cat ${this.petName} is sleeping now`)
//     }
// }

// const sleepingCat = new Animal('hollie')
// sleepingCat.sayMeow()

//Ошибка отсутсвия опеределения значения при передаче имени
// class Person {
//   constructor(name, age) {
//     this.name = name;
//     this.age = age
//   }

//   sayHi() {
//     console.log(`Hello, everyone`)
//   }
// }


// class Man extends Person {
//   constructor(name, age, height) {
//     super(name, age)
//     this.height = height
//   }

//   getName() {
//     super.sayHi()
//     console.log(`Hello, its me - ${this.name} ${this.age}, height - ${this.height}sm`)
//   }
//   getAge() {
//     return 22;
//   }
// }
// const oleksei = new Man('Oleksei', 39, 177)

// oleksei.getName()

// class Person {
//   constructor(name, age, gpa) {
//     this.name = name;
//     this.age = age;
//   }

//   hello() {
//     console.log("I'm here");
//   }
// }

// class Student extends Person {
//   constructor(name, age, gpa) {
//     super(name, age);
//     this.gpa = gpa;
//   }

//   hello() {
//     super.hello();
//     console.log(`Whats up ${this.gpa}`);
//   }
// }

// class Teacher extends Person {
//   constructor(name, age, classSize) {
//     super(name, age);
//     this.classSize = classSize;
//   }

//   hello() {
//     super.hello();
//     console.log("hello");
//   }
// }

// const studentOne = new Student('Halya', 9, 4)
// studentOne.hello()
