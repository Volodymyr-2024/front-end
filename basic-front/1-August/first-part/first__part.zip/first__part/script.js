const userName = document.querySelector("#name");
const phone = document.querySelector("#phone");
const email = document.querySelector("#email");
const password = document.querySelector("#password");
const signup__btn = document.querySelector(".signup__btn");
const emailLogin = document.querySelector("#emailLogin");
const passwordLogin = document.querySelector("#passwordLogin");
const signin__btn = document.querySelector(".signin__btn");
const signupForm = document.querySelector(".sign__up-form");
const requiredPar = document.createElement("p");
const storagedUser = localStorage.getItem("users");
const users = storagedUser ? JSON.parse(storagedUser) : [];
//ОДНО И ТОЖЕ ЧТО И ЗАПИСЬ НА 11 СТРОКЕ
// let isUser;
// if(storagedUser != undefined) {
//     isUser = JSON.parse(storagedUser)
// } else {
//     isUser = []
// }

signup__btn.addEventListener("click", () => {
  if (
    userName.value === "" ||
    phone.value === "" ||
    email.value === "" ||
    password.value === ""
  ) {
    requiredPar.innerText = "Все поля обязательны";
    requiredPar.style.color = "red";
  } else {
    let isError = false;
    for (let i = 0; i < users.length; i++) {
      if (users[i].email === email.value) {
        isError = true;
      }
    }
    if (isError) {
      requiredPar.innerText = "Пользователь с такой почтой уже существует!";
      requiredPar.style.color = "red";
    } else {
      const userData = {
        name: userName.value,
        phoneNumber: phone.value,
        email: email.value,
        password: password.value,
      };
      users.push(userData);
      localStorage.setItem("users", JSON.stringify(users));
      userName.value = "";
      phone.value = "";
      email.value = "";
      password.value = "";

      //сообщение о регистрации
      requiredPar.innerText = "Вы успешно зарегистрировались";
      requiredPar.style.color = "green";
    }
  }
  signupForm.appendChild(requiredPar);
});
